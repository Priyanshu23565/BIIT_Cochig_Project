const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const multer = require('multer');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Admin_!@1212',
    database: 'test_db1'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database.');
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/ftxe.html');
});

const upload = multer({ dest: 'uploads/' });

app.post('/submit', upload.single('photo'), (req, res) => {
    const {
        candidateName, fatherName, motherName, dob,
        category, casteCertificate, gender, religion,
        nationality, address, aadhaarNo, maritalStatus,course,aadhaarCard,educationCertificate,incomeCertificate,city,pinCode,contactNo,email
    } = req.body;
    const photo = req.file ? req.file.filename : null;

    const query = `
        INSERT INTO users4 (
            candidateName, fatherName, motherName, dob, category,
            casteCertificate, gender, religion, nationality, address,
            aadhaarNo, maritalStatus, photo,course,aadhaarCard,educationCertificate,incomeCertificate,city,pinCode,contactNo,email
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?)
    `;

    db.query(query, [
        candidateName, fatherName, motherName, dob,
        category, casteCertificate, gender, religion,
        nationality, address, aadhaarNo, maritalStatus, photo,course,aadhaarCard,educationCertificate,incomeCertificate,city,pinCode,contactNo,email
    ], (err) => {
        if (err) throw err;
        res.send('Data saved successfully!');
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
