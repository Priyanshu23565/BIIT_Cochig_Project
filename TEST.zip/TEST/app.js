const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Admin_!@1212',
    database: 'test_db'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database.');
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.post('/submit', (req, res) => {
    const { name, age, mobile, email,course } = req.body;
    console.log(`Received data - Name: ${name}, Age: ${age}, Mobile: ${mobile}, Email: ${email} , Email: ${email}`);
    db.query('INSERT INTO users (name, age, mobile, email) VALUES (?, ?, ?, ?)', [name, age, mobile, email], (err) => {
        if (err) throw err;
        res.send('Data saved successfully!');
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
